@extends('layout.home')
@section('content')
    <!-- Page Header section start here -->
    <div class="pageheader-section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="pageheader-content text-center">
                        <h2>Tutorial Posts</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="/">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Tutorial</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Header section ending here -->

    
    <!-- blog section start here -->
    <div class="blog-section padding-tb section-bg">
        <div class="container">
            <div class="section-wrapper">
                <div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 justify-content-center g-4">
                    @forelse ($tutorials as $tutorial)
              
                   @empty
                   <br>
                   <p class="text-center">Maaf, Hasil tidak ditemukan</p>
              
                   @endforelse
                    @foreach ($tutorials as $tutorial)
                        
                    <div class="col">
                        <div class="post-item">
                            <div class="post-inner">
                                <div class="post-thumb">
                                    <a href="{{ route('tutorials.show', $tutorial->slug) }}"><img src="{{ asset('storage/' . $tutorial->gambar) }}" alt="blog thumb" style="max-width: 390px; height: 250px;"></a>
                                </div>
                                <div class="post-content">
                                    <a href="{{ route('tutorials.show', $tutorial->slug) }}"><h4>{!! $tutorial->judul !!}</h4></a>
                                    <div class="meta-post">
                                        <ul class="lab-ul">
                                            <li><i class="icofont-ui-user"></i>{!! $tutorial->nama !!}</li>
                                            <li><i class="icofont-calendar"></i>{!! $tutorial->created_at !!}</li>
                                        </ul>
                                    </div>
                                    <p>{!! substr($tutorial->deskripsi, 0, 50) !!}</p>
                                </div>
                                <div class="post-footer">
                                    <div class="pf-left">
                                        <a href="{{ route('tutorials.show', $tutorial->slug) }}" class="lab-btn-text">Read more <i class="icofont-external-link"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach

                </div>
                <div>
                    {!! $tutorials->links() !!}
                </div>
            </div>
        </div>
    </div>
    <!-- blog section ending here -->
@endsection